Virtual Keyboard for Google Chrome&trade;
=========================================

## About
Virtual Keyboard for Google Chrome&trade; will popup automatically when the user clicks on an input field such as textboxes and textareas. Futhermore, the keyboard will disappear automatically once no longer needed.

This extension is ideal for touch screen devices. This keyboard works like an iOS/Android/Windows 8 touch virtual keyboard.

<img src="http://xontab.azurewebsites.net/Content/VirtualKeyboard/1.png" alt="" />

For more details visit: http://xontab.com/Apps/VirtualKeyboard/

## Future versions

Planned features are:
* Better support with WebComponents, Angular 1, 2+ and React
* Add support to HTML ContentEditable

You can also suggest new features: https://apps.xontab.com/Suggest/VirtualKeyboard/